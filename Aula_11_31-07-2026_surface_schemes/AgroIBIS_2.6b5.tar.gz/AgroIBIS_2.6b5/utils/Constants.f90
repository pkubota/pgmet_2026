!
!  $Author: pkubota $
!  $Date: 2008/09/23 17:51:54 $
!  $Revision: 1.9 $
!
MODULE Constants

  IMPLICIT NONE

  ! Selecting Kinds

  INTEGER, PARAMETER :: r4  = SELECTED_REAL_KIND(6)  ! Kind for 32-bits Real Numbers
  INTEGER, PARAMETER :: i4  = SELECTED_INT_KIND (9)   ! Kind for 32-bits Integer Numbers
  INTEGER, PARAMETER :: r8  = SELECTED_REAL_KIND(15) ! Kind for 64-bits Real Numbers
  INTEGER, PARAMETER :: i8  = SELECTED_INT_KIND (14)  ! Kind for 64-bits Integer Numbers
  INTEGER, PARAMETER :: r16 = SELECTED_REAL_KIND(31)! Kind for 128-bits Real Numbers

  REAL (KIND=r8), PARAMETER :: tice   = 271.16e0_r8! constant tice
  REAL (KIND=r8), PARAMETER :: icealv =    0.8e0_r8! constant icealv
  REAL (KIND=r8), PARAMETER :: icealn =    0.4e0_r8! constant icealn
  REAL (KIND=r8), PARAMETER :: oceald = 0.0419e0_r8! constant oceald
  REAL (KIND=r8), PARAMETER :: z0ice  =  0.001e0_r8! constant ice  
  REAL (KIND=r8), PARAMETER :: pi   = 3.1415927_r8   ! you know, that constant thingy


CONTAINS

  SUBROUTINE InitConstants () 


  END SUBROUTINE InitConstants
  
END MODULE Constants
