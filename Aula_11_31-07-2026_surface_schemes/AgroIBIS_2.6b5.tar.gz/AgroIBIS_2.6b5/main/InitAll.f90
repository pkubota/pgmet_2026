!
!    #    #    #     #     #####    ##    #       #
!    #    ##   #     #       #     #  #   #       #
!    #    # #  #     #       #    #    #  #       #
!    #    #  # #     #       #    ######  #       #
!    #    #   ##     #       #    #    #  #       #
!    #    #    #     #       #    #    #  ######  ######
!
!
!  $Author: pkubota $
!  $Date: 2008/09/23 17:51:54 $
!  $Revision: 1.9 $
!
MODULE InitAll
  USE Constants, Only: &
       r8,             &
       i8
  USE Options       , Only : InitOptions,dt,path_inp,idate,idatec,idatep,nfsibd,nfprt,nfsibt,&
                             fNameSibVeg,fNameSibmsk,ifday,tod,fNameIBISMask,fNameSSTAOI,&
			     fNameIBISDeltaTemp,fNameSandMask,fNameClayMask,fNameClimaTemp,&
			     RESTART,DELTAOUT,DELTAIN,UNDIMENSION
  USE Sfc_Ibis_Fiels, Only : InitFieldsIbis,nband,nsoilay,depth
  USE Sizes         , Only : InitSizes, ibMaxPerJB,iMax, jMax, kMax, ibMax, jbMax
  USE FieldsPhysics , Only : initFieldsPhysics
  USE Utils         , Only : InitUtils
  USE IbisOutput    , ONLY : Init_IbisOutput
  USE AtmosModel    , ONLY : RunAtmosModel,InitAtmosModel,RunAtmosModel1D

  IMPLICIT NONE
  PRIVATE
  PUBLIC :: InitA
CONTAINS

  SUBROUTINE InitA()  
    IMPLICIT NONE
    INTEGER :: nVars=345
    REAL(KIND=r8) :: xres
    REAL(KIND=r8) :: yres
        print*,'InitOptions'

    CALL InitOptions(iMax,jMax,kMax)    
    xres= 360.0_r8/REAL(iMax,kind=r8)
    yres= 180.0_r8/REAL(jMax,kind=r8)
         print*,'InitOptions'
   
    CALL InitSizes(iMax,jMax)
    print*,'InitUtils'
    CALL InitUtils(iMax,jMax)
    CALL initFieldsPhysics  (iMax,jMax,kMax,ibMax,jbMax)   
    CALL InitAtmosModel(ibMax,jbMax,nband)
    IF(.NOT.UNDIMENSION)THEN
       CALL RunAtmosModel  (1,dt,nband,dt,idate,idatec,idatep,DELTAIN)
    ELSE
       CALL RunAtmosModel1D(1,dt,nband,dt,idate,idatec,idatep,DELTAIN,.TRUE.)
    END IF
    CALL InitFieldsIbis (iMax,jMax,kMax,ibMax,jbMax,dt,xres,&
                         yres,idate,idatec,path_inp,nfsibd,nfprt,nfsibt,fNameSibVeg,&
                         fNameSibmsk,ifday ,ibMaxPerJB,tod ,fNameIBISMask,fNameSSTAOI,&
                         fNameIBISDeltaTemp,fNameSandMask,fNameClayMask,fNameClimaTemp,RESTART   )

    CALL Init_IbisOutput(nVars,ibMax,jbMax,nsoilay,DELTAOUT,dt,depth)

  END SUBROUTINE InitA
END MODULE InitAll
