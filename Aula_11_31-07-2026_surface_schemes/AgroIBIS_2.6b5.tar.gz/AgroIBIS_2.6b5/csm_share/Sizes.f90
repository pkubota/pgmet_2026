!
!  $Author: pkubota $
!  $Date: 2009/03/10 12:02:11 $
!  $Revision: 1.14 $
!
MODULE Sizes   ! Version 0 of Nov 25th, 2001
 IMPLICIT NONE

 INTEGER, ALLOCATABLE :: ibMaxPerJB(:)
 INTEGER            :: ibMax=-1
 INTEGER            :: jbMax=-1
 INTEGER            :: iMax=-1
 INTEGER            :: jMax=-1
 INTEGER            :: kMax=-1

CONTAINS

 SUBROUTINE InitSizes(iMax_in,jMax_in)
  INTEGER, INTENT(IN   ) :: iMax_in 
  INTEGER, INTENT(IN   ) :: jMax_in 

    ibMax=iMax_in
    jbMax=jMax_in
 
   ALLOCATE (ibMaxPerJB(0:jbmax))
   
   CALL GridDecomposition()
 END SUBROUTINE InitSizes

 SUBROUTINE GridDecomposition()
  
  ibMaxPerJB = ibmax
  ibMaxPerJB = ibmax

 END SUBROUTINE GridDecomposition

END MODULE Sizes
